import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { data: products } = await supabase.from('products').select('id');
    const { data: orders } = await supabase.from('orders').select('total, status');
    const totalRevenue = (orders || []).filter(o => o.status !== 'cancelled').reduce((s, o) => s + (o.total || 0), 0);
    const pendingOrders = (orders || []).filter(o => o.status === 'pending').length;
    return res.status(200).json({
      totalProducts: (products || []).length,
      totalOrders: (orders || []).length,
      totalRevenue,
      pendingOrders
    });
  } catch (err) {
    console.error('Stats API error:', err);
    res.status(500).json({ error: err.message });
  }
}
