import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { action } = req.body;

      if (action === 'login') {
        const { username, password } = req.body;
        const { data, error } = await supabase
          .from('admin_settings')
          .select('*')
          .eq('key', 'admin_credentials')
          .single();

        if (error || !data) {
          return res.status(401).json({ error: 'Admin not configured' });
        }

        const creds = typeof data.value === 'string' ? JSON.parse(data.value) : data.value;
        if (creds.username === username && creds.password === password) {
          // Generate a simple token
          const token = Buffer.from(`${username}:${Date.now()}:admin_secret_key`).toString('base64');
          // Store the token
          await supabase.from('admin_settings').upsert({
            key: 'admin_token',
            value: JSON.stringify({ token, created_at: new Date().toISOString() })
          }, { onConflict: 'key' });

          return res.status(200).json({ success: true, token, admin: { username: creds.username, name: creds.name || 'Admin' } });
        } else {
          return res.status(401).json({ error: 'Invalid credentials' });
        }
      }

      if (action === 'verify') {
        const { token } = req.body;
        const { data, error } = await supabase
          .from('admin_settings')
          .select('*')
          .eq('key', 'admin_token')
          .single();

        if (error || !data) return res.status(401).json({ error: 'Invalid token' });

        const stored = typeof data.value === 'string' ? JSON.parse(data.value) : data.value;
        if (stored.token === token) {
          // Get admin info
          const { data: credData } = await supabase
            .from('admin_settings')
            .select('*')
            .eq('key', 'admin_credentials')
            .single();
          const creds = credData ? (typeof credData.value === 'string' ? JSON.parse(credData.value) : credData.value) : {};
          return res.status(200).json({ valid: true, admin: { username: creds.username, name: creds.name || 'Admin' } });
        }
        return res.status(401).json({ error: 'Invalid token' });
      }

      if (action === 'change_password') {
        const { token, current_password, new_password, new_name } = req.body;
        // Verify token first
        const { data: tokenData } = await supabase
          .from('admin_settings')
          .select('*')
          .eq('key', 'admin_token')
          .single();
        if (!tokenData) return res.status(401).json({ error: 'Unauthorized' });
        const storedToken = typeof tokenData.value === 'string' ? JSON.parse(tokenData.value) : tokenData.value;
        if (storedToken.token !== token) return res.status(401).json({ error: 'Unauthorized' });

        // Get current creds
        const { data: credData } = await supabase
          .from('admin_settings')
          .select('*')
          .eq('key', 'admin_credentials')
          .single();
        if (!credData) return res.status(400).json({ error: 'No credentials found' });
        const creds = typeof credData.value === 'string' ? JSON.parse(credData.value) : credData.value;

        if (creds.password !== current_password) {
          return res.status(400).json({ error: 'Current password is incorrect' });
        }

        const updatedCreds = { ...creds };
        if (new_password) updatedCreds.password = new_password;
        if (new_name) updatedCreds.name = new_name;

        await supabase.from('admin_settings').update({ value: JSON.stringify(updatedCreds) }).eq('key', 'admin_credentials');
        return res.status(200).json({ success: true });
      }

      if (action === 'logout') {
        const { token } = req.body;
        await supabase.from('admin_settings').delete().eq('key', 'admin_token');
        return res.status(200).json({ success: true });
      }
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Admin auth error:', err);
    res.status(500).json({ error: err.message });
  }
}
