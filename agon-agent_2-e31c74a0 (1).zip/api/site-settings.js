import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('*')
        .in('key', ['site_name', 'site_currency', 'site_phone', 'site_email', 'site_address', 'delivery_fee', 'free_delivery_min']);
      if (error) throw error;
      const settings = {};
      (data || []).forEach(row => {
        try { settings[row.key] = JSON.parse(row.value); } catch { settings[row.key] = row.value; }
      });
      return res.status(200).json(settings);
    }

    if (req.method === 'PUT') {
      const { settings } = req.body;
      if (!settings) return res.status(400).json({ error: 'No settings provided' });

      for (const [key, value] of Object.entries(settings)) {
        await supabase.from('admin_settings').upsert(
          { key, value: JSON.stringify(value) },
          { onConflict: 'key' }
        );
      }
      return res.status(200).json({ success: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Settings error:', err);
    res.status(500).json({ error: err.message });
  }
}
