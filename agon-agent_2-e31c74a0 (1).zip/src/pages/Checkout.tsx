import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, CreditCard, Banknote, Building2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import { useCart } from '../lib/cartStore';

export default function Checkout() {
  const { lang, user } = useApp();
  const { items, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ customer_name: '', phone: '', address: '', city: '', payment_method: 'cod' });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          user_id: user?.id || null,
          user_email: user?.email || null,
          items,
          total,
        }),
      });
      if (res.ok) {
        setSuccess(true);
        clearCart();
        setTimeout(() => navigate('/orders'), 3000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-slate-900 pt-24 pb-16 flex items-center justify-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center">
          <CheckCircle size={80} className="mx-auto text-green-400 mb-6" />
          <h2 className="text-3xl font-bold text-white mb-3">{t('checkout.success', lang)}</h2>
          <p className="text-gray-400">{lang === 'ar' ? 'سيتم تحويلك لصفحة الطلبات...' : 'Redirecting to orders...'}</p>
        </motion.div>
      </div>
    );
  }

  const paymentMethods = [
    { value: 'cod', label: t('checkout.cod', lang), icon: <Banknote size={20} /> },
    { value: 'card', label: t('checkout.card', lang), icon: <CreditCard size={20} /> },
    { value: 'transfer', label: t('checkout.transfer', lang), icon: <Building2 size={20} /> },
  ];

  return (
    <div className="min-h-screen bg-slate-900 pt-24 pb-16">
      <div className="max-w-2xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-8">{t('checkout.title', lang)}</h1>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-400 text-sm mb-2">{t('checkout.name', lang)}</label>
              <input required value={form.customer_name} onChange={e => setForm({...form, customer_name: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
            </div>
            <div>
              <label className="block text-gray-400 text-sm mb-2">{t('checkout.phone', lang)}</label>
              <input required value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">{t('checkout.address', lang)}</label>
            <input required value={form.address} onChange={e => setForm({...form, address: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">{t('checkout.city', lang)}</label>
            <input required value={form.city} onChange={e => setForm({...form, city: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-4">{t('checkout.payment', lang)}</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {paymentMethods.map(pm => (
                <button
                  key={pm.value}
                  type="button"
                  onClick={() => setForm({...form, payment_method: pm.value})}
                  className={`flex items-center gap-3 p-4 rounded-xl border transition-all ${
                    form.payment_method === pm.value
                      ? 'border-amber-500 bg-amber-500/10 text-amber-400'
                      : 'border-slate-700 bg-slate-800 text-gray-400 hover:border-slate-600'
                  }`}
                >
                  {pm.icon}
                  <span className="text-sm font-medium">{pm.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex justify-between mb-2">
              <span className="text-gray-400">{lang === 'ar' ? 'عدد المنتجات' : 'Items'}</span>
              <span className="text-white">{items.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400 text-lg">{t('cart.total', lang)}</span>
              <span className="text-2xl font-black text-amber-400">{total.toFixed(2)} {t('currency', lang)}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting || items.length === 0}
            className="w-full py-4 bg-amber-500 text-slate-900 font-bold text-lg rounded-2xl hover:bg-amber-400 transition-colors disabled:opacity-50 active:scale-[0.98]"
          >
            {submitting ? (lang === 'ar' ? 'جاري التأكيد...' : 'Processing...') : t('checkout.place', lang)}
          </button>
        </form>
      </div>
    </div>
  );
}
