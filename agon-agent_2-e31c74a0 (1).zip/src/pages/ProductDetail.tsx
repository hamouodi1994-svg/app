import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, ArrowRight, ArrowLeft, Star, Package, Truck } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import { useCart } from '../lib/cartStore';
import LoadingSpinner from '../components/LoadingSpinner';

export default function ProductDetail() {
  const { id } = useParams();
  const { lang } = useApp();
  const { addItem } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);
  const Arrow = lang === 'ar' ? ArrowRight : ArrowLeft;

  useEffect(() => {
    fetch(`/api/products?id=${id}`)
      .then(r => r.json())
      .then(setProduct)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="min-h-screen bg-slate-900 pt-24"><LoadingSpinner /></div>;
  if (!product) return <div className="min-h-screen bg-slate-900 pt-24 text-center text-gray-400 py-20">{lang === 'ar' ? 'المنتج غير موجود' : 'Product not found'}</div>;

  const name = lang === 'ar' ? product.name_ar : product.name_en;
  const desc = lang === 'ar' ? product.description_ar : product.description_en;

  const handleAdd = () => {
    addItem({ id: product.id, name_ar: product.name_ar, name_en: product.name_en, price: product.price, image_url: product.image_url });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-900 pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-4">
        <Link to="/products" className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 mb-8 text-sm">
          <Arrow size={16} /> {lang === 'ar' ? 'العودة للمنتجات' : 'Back to Products'}
        </Link>
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="rounded-2xl overflow-hidden">
            <img src={product.image_url} alt={name} className="w-full aspect-square object-cover rounded-2xl" />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col">
            <span className="text-amber-400 text-sm font-medium mb-2">{t(`categories.${product.category}`, lang)}</span>
            <h1 className="text-3xl font-bold text-white mb-4">{name}</h1>
            <div className="flex items-center gap-2 mb-6">
              {[1,2,3,4,5].map(i => <Star key={i} size={16} className={i <= 4 ? 'text-amber-400 fill-amber-400' : 'text-gray-600'} />)}
              <span className="text-gray-400 text-sm">(4.0)</span>
            </div>
            <p className="text-gray-300 leading-relaxed mb-8">{desc}</p>
            <div className="flex items-center gap-4 mb-8">
              <span className="text-4xl font-black text-amber-400">{product.price}</span>
              <span className="text-gray-400">{t('currency', lang)}</span>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <button
                onClick={handleAdd}
                className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 rounded-2xl font-bold text-lg transition-all active:scale-95 ${
                  added ? 'bg-green-500 text-white' : 'bg-amber-500 text-slate-900 hover:bg-amber-400'
                }`}
              >
                <ShoppingCart size={20} />
                {added ? (lang === 'ar' ? 'تمت الإضافة ✓' : 'Added ✓') : t('product.addToCart', lang)}
              </button>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-400 text-sm">
                <Package size={16} className="text-amber-400" />
                {lang === 'ar' ? `متوفر في المخزون (${product.stock} قطعة)` : `In stock (${product.stock} units)`}
              </div>
              <div className="flex items-center gap-3 text-gray-400 text-sm">
                <Truck size={16} className="text-amber-400" />
                {lang === 'ar' ? 'توصيل سريع خلال 24-48 ساعة' : 'Fast delivery in 24-48 hours'}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
