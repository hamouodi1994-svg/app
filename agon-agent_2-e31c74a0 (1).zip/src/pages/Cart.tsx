
import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import { useCart } from '../lib/cartStore';

export default function Cart() {
  const { lang } = useApp();
  const { items, removeItem, updateQuantity, total, count } = useCart();

  return (
    <div className="min-h-screen bg-slate-900 pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-8">{t('cart.title', lang)} ({count})</h1>

        {items.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingBag size={64} className="mx-auto text-gray-600 mb-4" />
            <p className="text-gray-400 text-lg mb-6">{t('cart.empty', lang)}</p>
            <Link to="/products" className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-bold rounded-xl hover:bg-amber-400 transition-colors">
              {t('hero.cta', lang)}
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            <AnimatePresence>
              {items.map(item => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  className="flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50"
                >
                  <img src={item.image_url} alt="" className="w-20 h-20 rounded-xl object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-medium text-sm truncate">{lang === 'ar' ? item.name_ar : item.name_en}</h3>
                    <p className="text-amber-400 font-bold mt-1">{item.price} {t('currency', lang)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-1.5 rounded-lg bg-slate-700 text-gray-300 hover:bg-slate-600">
                      <Minus size={14} />
                    </button>
                    <span className="text-white font-medium w-8 text-center">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-1.5 rounded-lg bg-slate-700 text-gray-300 hover:bg-slate-600">
                      <Plus size={14} />
                    </button>
                  </div>
                  <div className="text-end">
                    <p className="text-white font-bold">{(item.price * item.quantity).toFixed(2)}</p>
                    <button onClick={() => removeItem(item.id)} className="text-red-400 hover:text-red-300 mt-1">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            <div className="mt-8 p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50">
              <div className="flex items-center justify-between mb-6">
                <span className="text-gray-400 text-lg">{t('cart.total', lang)}</span>
                <span className="text-3xl font-black text-amber-400">{total.toFixed(2)} <span className="text-sm text-gray-400">{t('currency', lang)}</span></span>
              </div>
              <Link
                to="/checkout"
                className="block w-full text-center px-6 py-4 bg-amber-500 text-slate-900 font-bold text-lg rounded-2xl hover:bg-amber-400 transition-colors active:scale-[0.98]"
              >
                {t('cart.checkout', lang)}
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
