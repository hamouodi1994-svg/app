import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, ShoppingCart, DollarSign, Users, Plus, Edit3, Trash2, X, Upload, Image as ImageIcon, Settings, LogOut, Shield, Save, Eye, EyeOff, RefreshCw, Clock, CheckCircle, Truck, XCircle, BarChart3 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import LoadingSpinner from '../components/LoadingSpinner';

interface Stats { totalProducts: number; totalOrders: number; totalRevenue: number; pendingOrders: number; }

const statusIcons: Record<string, { icon: any; color: string; bg: string }> = {
  pending: { icon: Clock, color: 'text-yellow-400', bg: 'bg-yellow-400/10 border-yellow-400/20' },
  shipped: { icon: Truck, color: 'text-blue-400', bg: 'bg-blue-400/10 border-blue-400/20' },
  delivered: { icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-400/10 border-green-400/20' },
  cancelled: { icon: XCircle, color: 'text-red-400', bg: 'bg-red-400/10 border-red-400/20' },
};

export default function Admin() {
  const { lang } = useApp();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [authenticated, setAuthenticated] = useState(false);
  const [verifying, setVerifying] = useState(true);
  const [adminInfo, setAdminInfo] = useState<any>(null);

  const [tab, setTab] = useState<'stats' | 'products' | 'orders' | 'settings'>('stats');
  const [stats, setStats] = useState<Stats | null>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState<any>(null);
  const [form, setForm] = useState({ name_ar: '', name_en: '', description_ar: '', description_en: '', price: '', category: 'clothing', image_url: '', stock: '100', featured: false });
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [savingProduct, setSavingProduct] = useState(false);

  // Settings state
  const [siteSettings, setSiteSettings] = useState({
    site_name: { ar: 'سوق الأناقة', en: 'Elegance Market' },
    site_currency: 'د.م',
    site_phone: '+212 600 000 000',
    site_email: 'contact@souq-elegance.com',
    site_address: { ar: 'الدار البيضاء، المغرب', en: 'Casablanca, Morocco' },
    delivery_fee: 30,
    free_delivery_min: 500,
  });
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // Password change
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ current: '', newPass: '', newName: '' });
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [showOldPass, setShowOldPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);

  // Verify admin token on mount
  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      setVerifying(false);
      navigate('/admin-login');
      return;
    }
    fetch('/api/admin-auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'verify', token }),
    })
      .then(r => r.json())
      .then(data => {
        if (data.valid) {
          setAuthenticated(true);
          setAdminInfo(data.admin);
        } else {
          localStorage.removeItem('admin_token');
          localStorage.removeItem('admin_info');
          navigate('/admin-login');
        }
      })
      .catch(() => {
        navigate('/admin-login');
      })
      .finally(() => setVerifying(false));
  }, [navigate]);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [s, p, o] = await Promise.all([
        fetch('/api/stats').then(r => r.json()),
        fetch('/api/products').then(r => r.json()),
        fetch('/api/orders?all=true').then(r => r.json()),
      ]);
      setStats(s);
      setProducts(Array.isArray(p) ? p : []);
      setOrders(Array.isArray(o) ? o : []);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/site-settings');
      const data = await res.json();
      if (data && typeof data === 'object' && !data.error) {
        setSiteSettings(prev => ({ ...prev, ...data }));
      }
    } catch (err) { console.error(err); }
  };

  useEffect(() => {
    if (authenticated) {
      fetchAll();
      fetchSettings();
    }
  }, [authenticated]);

  // Image upload handler
  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file
    if (!file.type.startsWith('image/')) {
      alert(lang === 'ar' ? 'يرجى اختيار ملف صورة صالح' : 'Please select a valid image file');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      alert(lang === 'ar' ? 'حجم الصورة يجب أن لا يتجاوز 10MB' : 'Image size must not exceed 10MB');
      return;
    }

    // Read as base64
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const base64 = ev.target?.result as string;
      setImagePreview(base64);
      setUploading(true);

      try {
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64, filename: file.name }),
        });
        const data = await res.json();
        if (data.url) {
          setForm(prev => ({ ...prev, image_url: data.url }));
        }
      } catch (err) {
        console.error('Upload failed:', err);
        // Fallback: use base64 directly
        setForm(prev => ({ ...prev, image_url: base64 }));
      } finally {
        setUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProduct(true);
    const body = { ...form, price: parseFloat(form.price), stock: parseInt(form.stock) };
    try {
      if (editProduct) {
        await fetch('/api/products', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: editProduct.id, ...body }) });
      } else {
        await fetch('/api/products', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      }
      setShowForm(false);
      setEditProduct(null);
      setImagePreview(null);
      setForm({ name_ar: '', name_en: '', description_ar: '', description_en: '', price: '', category: 'clothing', image_url: '', stock: '100', featured: false });
      fetchAll();
    } finally {
      setSavingProduct(false);
    }
  };

  const handleDeleteProduct = async (id: number) => {
    if (!confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذا المنتج؟' : 'Are you sure you want to delete this product?')) return;
    await fetch('/api/products', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    fetchAll();
  };

  const handleUpdateOrderStatus = async (id: number, status: string) => {
    await fetch('/api/orders', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
    fetchAll();
  };

  const handleDeleteOrder = async (id: number) => {
    if (!confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذا الطلب؟' : 'Delete this order?')) return;
    await fetch('/api/orders', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    fetchAll();
  };

  const openEdit = (p: any) => {
    setEditProduct(p);
    setForm({ name_ar: p.name_ar, name_en: p.name_en, description_ar: p.description_ar, description_en: p.description_en, price: String(p.price), category: p.category, image_url: p.image_url, stock: String(p.stock), featured: p.featured });
    setImagePreview(p.image_url);
    setShowForm(true);
  };

  const openNewProduct = () => {
    setEditProduct(null);
    setForm({ name_ar: '', name_en: '', description_ar: '', description_en: '', price: '', category: 'clothing', image_url: '', stock: '100', featured: false });
    setImagePreview(null);
    setShowForm(true);
  };

  const handleSaveSettings = async () => {
    setSavingSettings(true);
    try {
      await fetch('/api/site-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: siteSettings }),
      });
      setSettingsSuccess(true);
      setTimeout(() => setSettingsSuccess(false), 3000);
    } catch (err) { console.error(err); }
    finally { setSavingSettings(false); }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess(false);
    const token = localStorage.getItem('admin_token');
    try {
      const res = await fetch('/api/admin-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'change_password', token, current_password: passwordForm.current, new_password: passwordForm.newPass || undefined, new_name: passwordForm.newName || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setPasswordSuccess(true);
      setPasswordForm({ current: '', newPass: '', newName: '' });
      setTimeout(() => { setPasswordSuccess(false); setShowPasswordForm(false); }, 2000);
    } catch (err: any) {
      setPasswordError(err.message);
    }
  };

  const handleLogout = async () => {
    const token = localStorage.getItem('admin_token');
    await fetch('/api/admin-auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'logout', token }),
    });
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_info');
    navigate('/admin-login');
  };

  if (verifying) return <div className="min-h-screen bg-slate-900 pt-24"><LoadingSpinner /></div>;
  if (!authenticated) return null;
  if (loading) return <div className="min-h-screen bg-slate-900 pt-24"><LoadingSpinner /></div>;

  const statCards = stats ? [
    { label: t('admin.totalProducts', lang), value: stats.totalProducts, icon: <Package size={24} />, color: 'from-blue-500 to-blue-600' },
    { label: t('admin.totalOrders', lang), value: stats.totalOrders, icon: <ShoppingCart size={24} />, color: 'from-green-500 to-green-600' },
    { label: t('admin.totalRevenue', lang), value: `${stats.totalRevenue.toFixed(0)} ${t('currency', lang)}`, icon: <DollarSign size={24} />, color: 'from-amber-500 to-amber-600' },
    { label: lang === 'ar' ? 'طلبات معلقة' : 'Pending', value: stats.pendingOrders, icon: <Users size={24} />, color: 'from-purple-500 to-purple-600' },
  ] : [];

  const tabs = [
    { key: 'stats' as const, label: lang === 'ar' ? 'الإحصائيات' : 'Statistics', icon: <BarChart3 size={16} /> },
    { key: 'products' as const, label: lang === 'ar' ? 'المنتجات' : 'Products', icon: <Package size={16} /> },
    { key: 'orders' as const, label: lang === 'ar' ? 'الطلبات' : 'Orders', icon: <ShoppingCart size={16} /> },
    { key: 'settings' as const, label: lang === 'ar' ? 'الإعدادات' : 'Settings', icon: <Settings size={16} /> },
  ];

  return (
    <div className="min-h-screen bg-slate-900 pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        {/* Admin Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
              <Shield size={22} className="text-slate-900" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{lang === 'ar' ? 'لوحة التحكم' : 'Admin Dashboard'}</h1>
              <p className="text-gray-400 text-sm">{lang === 'ar' ? 'مرحباً،' : 'Welcome,'} {adminInfo?.name || 'Admin'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={fetchAll} className="p-2.5 rounded-xl bg-slate-700 text-gray-300 hover:bg-slate-600 hover:text-white transition-all" title={lang === 'ar' ? 'تحديث' : 'Refresh'}>
              <RefreshCw size={16} />
            </button>
            <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all text-sm font-medium">
              <LogOut size={16} />
              {lang === 'ar' ? 'خروج' : 'Logout'}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
          {tabs.map(tb => (
            <button key={tb.key} onClick={() => setTab(tb.key)} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
              tab === tb.key ? 'bg-amber-500 text-slate-900' : 'bg-slate-800 text-gray-400 hover:text-white hover:bg-slate-700'
            }`}>
              {tb.icon} {tb.label}
            </button>
          ))}
        </div>

        {/* Stats Tab */}
        {tab === 'stats' && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {statCards.map((s, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center text-white mb-4`}>{s.icon}</div>
                <p className="text-gray-400 text-sm mb-1">{s.label}</p>
                <p className="text-2xl font-bold text-white">{s.value}</p>
              </motion.div>
            ))}
          </div>
        )}

        {/* Products Tab */}
        {tab === 'products' && (
          <div>
            <button onClick={openNewProduct}
              className="mb-6 flex items-center gap-2 px-5 py-3 bg-amber-500 text-slate-900 font-bold rounded-xl hover:bg-amber-400 transition-colors">
              <Plus size={18} /> {t('admin.addProduct', lang)}
            </button>

            {/* Product Form */}
            <AnimatePresence>
              {showForm && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-6 overflow-hidden">
                  <form onSubmit={handleSaveProduct} className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50 space-y-5">
                    <div className="flex justify-between items-center">
                      <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                        {editProduct ? <Edit3 size={18} className="text-amber-400" /> : <Plus size={18} className="text-amber-400" />}
                        {editProduct ? (lang === 'ar' ? 'تعديل المنتج' : 'Edit Product') : (lang === 'ar' ? 'إضافة منتج جديد' : 'Add New Product')}
                      </h3>
                      <button type="button" onClick={() => { setShowForm(false); setImagePreview(null); }} className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-slate-700 transition-all"><X size={20} /></button>
                    </div>

                    {/* Image Upload Section */}
                    <div className="p-4 rounded-xl bg-slate-900/50 border border-dashed border-slate-600">
                      <label className="block text-gray-300 text-sm font-medium mb-3">
                        <ImageIcon size={16} className="inline-block me-1.5 text-amber-400" />
                        {lang === 'ar' ? 'صورة المنتج' : 'Product Image'}
                      </label>
                      <div className="flex flex-col sm:flex-row items-start gap-4">
                        {/* Preview */}
                        <div className="w-32 h-32 rounded-xl bg-slate-800 border border-slate-700 overflow-hidden flex-shrink-0 flex items-center justify-center">
                          {imagePreview || form.image_url ? (
                            <img src={imagePreview || form.image_url} alt="Preview" className="w-full h-full object-cover" />
                          ) : (
                            <div className="text-center">
                              <ImageIcon size={32} className="mx-auto text-gray-600 mb-1" />
                              <span className="text-gray-500 text-xs">{lang === 'ar' ? 'لا توجد صورة' : 'No image'}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex-1 space-y-3">
                          {/* Upload Button */}
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleImageSelect}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={uploading}
                            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-700 text-gray-200 hover:bg-slate-600 transition-all text-sm font-medium disabled:opacity-50"
                          >
                            {uploading ? (
                              <><div className="w-4 h-4 border-2 border-gray-400/30 border-t-gray-300 rounded-full animate-spin" /> {lang === 'ar' ? 'جاري الرفع...' : 'Uploading...'}</>
                            ) : (
                              <><Upload size={16} /> {lang === 'ar' ? 'رفع صورة من الجهاز' : 'Upload from device'}</>
                            )}
                          </button>
                          {/* Or URL input */}
                          <div className="flex items-center gap-2">
                            <div className="h-px flex-1 bg-slate-700" />
                            <span className="text-gray-500 text-xs">{lang === 'ar' ? 'أو أدخل رابط' : 'or enter URL'}</span>
                            <div className="h-px flex-1 bg-slate-700" />
                          </div>
                          <input
                            placeholder={lang === 'ar' ? 'رابط الصورة (URL)' : 'Image URL'}
                            value={form.image_url}
                            onChange={e => { setForm({...form, image_url: e.target.value}); setImagePreview(e.target.value); }}
                            className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-500 focus:outline-none transition-colors placeholder-gray-500"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Product Info */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الاسم بالعربية' : 'Arabic Name'} *</label>
                        <input required value={form.name_ar} onChange={e => setForm({...form, name_ar: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors" />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الاسم بالإنجليزية' : 'English Name'} *</label>
                        <input required value={form.name_en} onChange={e => setForm({...form, name_en: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors" />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الوصف بالعربية' : 'Arabic Description'} *</label>
                        <textarea required value={form.description_ar} onChange={e => setForm({...form, description_ar: e.target.value})} rows={3} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors resize-none" />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الوصف بالإنجليزية' : 'English Description'} *</label>
                        <textarea required value={form.description_en} onChange={e => setForm({...form, description_en: e.target.value})} rows={3} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors resize-none" />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'السعر' : 'Price'} *</label>
                        <input required type="number" step="0.01" min="0" value={form.price} onChange={e => setForm({...form, price: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors" />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الفئة' : 'Category'} *</label>
                        <select value={form.category} onChange={e => setForm({...form, category: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors">
                          <option value="clothing">{t('categories.clothing', lang)}</option>
                          <option value="electronics">{t('categories.electronics', lang)}</option>
                          <option value="perfumes">{t('categories.perfumes', lang)}</option>
                          <option value="general">{t('categories.general', lang)}</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'المخزون' : 'Stock'} *</label>
                        <input required type="number" min="0" value={form.stock} onChange={e => setForm({...form, stock: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none transition-colors" />
                      </div>
                      <div className="flex items-end">
                        <label className="flex items-center gap-3 cursor-pointer p-3 rounded-xl bg-slate-900 border border-slate-700 w-full">
                          <input type="checkbox" checked={form.featured} onChange={e => setForm({...form, featured: e.target.checked})} className="w-5 h-5 rounded border-slate-600 text-amber-500 focus:ring-amber-500" />
                          <span className="text-gray-300 text-sm">{lang === 'ar' ? 'منتج مميز (يظهر في الصفحة الرئيسية)' : 'Featured (shown on homepage)'}</span>
                        </label>
                      </div>
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button type="submit" disabled={savingProduct || !form.image_url} className="flex items-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-bold rounded-xl hover:bg-amber-400 transition-colors disabled:opacity-50">
                        {savingProduct ? <div className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" /> : <Save size={16} />}
                        {savingProduct ? (lang === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (lang === 'ar' ? 'حفظ المنتج' : 'Save Product')}
                      </button>
                      <button type="button" onClick={() => { setShowForm(false); setImagePreview(null); }} className="px-6 py-3 bg-slate-700 text-gray-300 rounded-xl hover:bg-slate-600 transition-colors">
                        {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map(p => (
                <motion.div key={p.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  className="rounded-2xl bg-slate-800/50 border border-slate-700/50 overflow-hidden hover:border-slate-600 transition-all">
                  <div className="relative aspect-video">
                    <img src={p.image_url} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                    {p.featured && (
                      <span className="absolute top-2 start-2 px-2 py-1 rounded-lg bg-amber-500 text-slate-900 text-xs font-bold">
                        {lang === 'ar' ? '⭐ مميز' : '⭐ Featured'}
                      </span>
                    )}
                    <span className="absolute top-2 end-2 px-2 py-1 rounded-lg bg-slate-900/80 text-gray-300 text-xs">
                      #{p.id}
                    </span>
                  </div>
                  <div className="p-4">
                    <h3 className="text-white font-semibold text-sm mb-1 truncate">{lang === 'ar' ? p.name_ar : p.name_en}</h3>
                    <p className="text-gray-400 text-xs mb-3 truncate">{lang === 'ar' ? p.description_ar : p.description_en}</p>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-amber-400 font-bold">{p.price} {t('currency', lang)}</span>
                      <span className="text-gray-500 text-xs">{lang === 'ar' ? `المخزون: ${p.stock}` : `Stock: ${p.stock}`}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-lg bg-slate-700 text-gray-300 text-xs">{t(`categories.${p.category}`, lang)}</span>
                      <div className="flex gap-1.5">
                        <button onClick={() => openEdit(p)} className="p-2 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors" title={lang === 'ar' ? 'تعديل' : 'Edit'}>
                          <Edit3 size={14} />
                        </button>
                        <button onClick={() => handleDeleteProduct(p.id)} className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors" title={lang === 'ar' ? 'حذف' : 'Delete'}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Orders Tab */}
        {tab === 'orders' && (
          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="text-center py-20 text-gray-400">
                <ShoppingCart size={48} className="mx-auto mb-3 text-gray-600" />
                {lang === 'ar' ? 'لا توجد طلبات بعد' : 'No orders yet'}
              </div>
            ) : orders.map((order, i) => {
              const items = typeof order.items === 'string' ? JSON.parse(order.items) : order.items;
              const sc = statusIcons[order.status] || statusIcons.pending;
              const StatusIcon = sc.icon;
              return (
                <motion.div key={order.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
                  className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700/50 hover:border-slate-600 transition-all">
                  <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-gray-500 text-xs font-mono">#{order.id}</span>
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium border ${sc.bg} ${sc.color}`}>
                          <StatusIcon size={12} />
                          {t(`orders.${order.status}`, lang)}
                        </span>
                      </div>
                      <h3 className="text-white font-semibold">{order.customer_name}</h3>
                      <p className="text-gray-400 text-sm">{order.phone} — {order.city}</p>
                      <p className="text-gray-500 text-xs mt-0.5">{order.address}</p>
                      {order.user_email && <p className="text-gray-500 text-xs mt-0.5">{order.user_email}</p>}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <select
                        value={order.status}
                        onChange={e => handleUpdateOrderStatus(order.id, e.target.value)}
                        className="px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white text-sm focus:border-amber-500 focus:outline-none"
                      >
                        <option value="pending">{t('orders.pending', lang)}</option>
                        <option value="shipped">{t('orders.shipped', lang)}</option>
                        <option value="delivered">{t('orders.delivered', lang)}</option>
                        <option value="cancelled">{t('orders.cancelled', lang)}</option>
                      </select>
                      <button onClick={() => handleDeleteOrder(order.id)} className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors" title={lang === 'ar' ? 'حذف الطلب' : 'Delete Order'}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {(items || []).map((item: any, j: number) => (
                      <div key={j} className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-900/80 border border-slate-700/50 text-xs text-gray-300">
                        <img src={item.image_url} alt="" className="w-8 h-8 rounded object-cover" />
                        <span className="truncate max-w-[100px]">{lang === 'ar' ? item.name_ar : item.name_en}</span>
                        <span className="text-amber-400 font-medium">x{item.quantity}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between text-sm pt-2 border-t border-slate-700/50">
                    <div className="flex items-center gap-3">
                      <span className="text-gray-500 text-xs">{new Date(order.created_at).toLocaleString(lang === 'ar' ? 'ar-MA' : 'en-US')}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-700 text-gray-400 text-xs">{lang === 'ar' ? ({'cod':'دفع عند الاستلام','card':'بطاقة بنكية','transfer':'تحويل بنكي'} as Record<string,string>)[order.payment_method] || order.payment_method : order.payment_method}</span>
                    </div>
                    <span className="text-amber-400 font-bold text-lg">{order.total} {t('currency', lang)}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Settings Tab */}
        {tab === 'settings' && (
          <div className="space-y-6">
            {/* Site Settings */}
            <div className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-white font-semibold text-lg mb-6 flex items-center gap-2">
                <Settings size={18} className="text-amber-400" />
                {lang === 'ar' ? 'إعدادات الموقع' : 'Site Settings'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'اسم الموقع (عربي)' : 'Site Name (Arabic)'}</label>
                  <input value={typeof siteSettings.site_name === 'object' ? siteSettings.site_name.ar : siteSettings.site_name} onChange={e => setSiteSettings({...siteSettings, site_name: { ...(typeof siteSettings.site_name === 'object' ? siteSettings.site_name : { ar: '', en: '' }), ar: e.target.value }})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'اسم الموقع (إنجليزي)' : 'Site Name (English)'}</label>
                  <input value={typeof siteSettings.site_name === 'object' ? siteSettings.site_name.en : ''} onChange={e => setSiteSettings({...siteSettings, site_name: { ...(typeof siteSettings.site_name === 'object' ? siteSettings.site_name : { ar: '', en: '' }), en: e.target.value }})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'العملة' : 'Currency'}</label>
                  <input value={siteSettings.site_currency} onChange={e => setSiteSettings({...siteSettings, site_currency: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'رقم الهاتف' : 'Phone'}</label>
                  <input value={siteSettings.site_phone} onChange={e => setSiteSettings({...siteSettings, site_phone: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'البريد الإلكتروني' : 'Email'}</label>
                  <input value={siteSettings.site_email} onChange={e => setSiteSettings({...siteSettings, site_email: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'رسوم التوصيل' : 'Delivery Fee'}</label>
                  <input type="number" value={siteSettings.delivery_fee} onChange={e => setSiteSettings({...siteSettings, delivery_fee: parseFloat(e.target.value) || 0})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الحد الأدنى للتوصيل المجاني' : 'Free Delivery Min'}</label>
                  <input type="number" value={siteSettings.free_delivery_min} onChange={e => setSiteSettings({...siteSettings, free_delivery_min: parseFloat(e.target.value) || 0})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'العنوان (عربي)' : 'Address (Arabic)'}</label>
                  <input value={typeof siteSettings.site_address === 'object' ? siteSettings.site_address.ar : siteSettings.site_address} onChange={e => setSiteSettings({...siteSettings, site_address: { ...(typeof siteSettings.site_address === 'object' ? siteSettings.site_address : { ar: '', en: '' }), ar: e.target.value }})} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                </div>
              </div>
              <div className="mt-6 flex items-center gap-3">
                <button onClick={handleSaveSettings} disabled={savingSettings} className="flex items-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-bold rounded-xl hover:bg-amber-400 transition-colors disabled:opacity-50">
                  {savingSettings ? <div className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" /> : <Save size={16} />}
                  {savingSettings ? (lang === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (lang === 'ar' ? 'حفظ الإعدادات' : 'Save Settings')}
                </button>
                {settingsSuccess && (
                  <motion.span initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="text-green-400 text-sm flex items-center gap-1">
                    <CheckCircle size={14} /> {lang === 'ar' ? 'تم الحفظ بنجاح' : 'Saved successfully'}
                  </motion.span>
                )}
              </div>
            </div>

            {/* Account Settings */}
            <div className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-white font-semibold text-lg mb-4 flex items-center gap-2">
                <Shield size={18} className="text-amber-400" />
                {lang === 'ar' ? 'إعدادات الحساب' : 'Account Settings'}
              </h3>
              <p className="text-gray-400 text-sm mb-4">
                {lang === 'ar' ? 'تغيير كلمة المرور أو اسم المدير' : 'Change admin password or display name'}
              </p>

              {!showPasswordForm ? (
                <button onClick={() => setShowPasswordForm(true)} className="flex items-center gap-2 px-5 py-3 bg-slate-700 text-gray-200 rounded-xl hover:bg-slate-600 transition-colors text-sm font-medium">
                  <Edit3 size={16} />
                  {lang === 'ar' ? 'تعديل بيانات الحساب' : 'Edit Account Info'}
                </button>
              ) : (
                <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
                  {passwordError && (
                    <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{passwordError}</div>
                  )}
                  {passwordSuccess && (
                    <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-sm flex items-center gap-2">
                      <CheckCircle size={14} /> {lang === 'ar' ? 'تم التحديث بنجاح!' : 'Updated successfully!'}
                    </div>
                  )}
                  <div>
                    <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'الاسم الجديد (اختياري)' : 'New Display Name (optional)'}</label>
                    <input value={passwordForm.newName} onChange={e => setPasswordForm({...passwordForm, newName: e.target.value})} placeholder={adminInfo?.name || 'Admin'} className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'كلمة المرور الحالية' : 'Current Password'} *</label>
                    <div className="relative">
                      <input required type={showOldPass ? 'text' : 'password'} value={passwordForm.current} onChange={e => setPasswordForm({...passwordForm, current: e.target.value})} className="w-full px-4 py-3 pe-12 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                      <button type="button" onClick={() => setShowOldPass(!showOldPass)} className="absolute top-1/2 -translate-y-1/2 end-4 text-gray-500 hover:text-gray-300">
                        {showOldPass ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-400 text-xs mb-1.5">{lang === 'ar' ? 'كلمة المرور الجديدة (اختياري)' : 'New Password (optional)'}</label>
                    <div className="relative">
                      <input type={showNewPass ? 'text' : 'password'} value={passwordForm.newPass} onChange={e => setPasswordForm({...passwordForm, newPass: e.target.value})} placeholder="••••••••" className="w-full px-4 py-3 pe-12 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-amber-500 focus:outline-none" />
                      <button type="button" onClick={() => setShowNewPass(!showNewPass)} className="absolute top-1/2 -translate-y-1/2 end-4 text-gray-500 hover:text-gray-300">
                        {showNewPass ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button type="submit" className="flex items-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-bold rounded-xl hover:bg-amber-400 transition-colors">
                      <Save size={16} /> {lang === 'ar' ? 'حفظ التغييرات' : 'Save Changes'}
                    </button>
                    <button type="button" onClick={() => { setShowPasswordForm(false); setPasswordError(''); }} className="px-6 py-3 bg-slate-700 text-gray-300 rounded-xl hover:bg-slate-600">
                      {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
