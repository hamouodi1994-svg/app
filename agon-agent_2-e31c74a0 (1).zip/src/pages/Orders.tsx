import React, { useState, useEffect } from 'react';
import { Package, Clock, Truck, CheckCircle, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import LoadingSpinner from '../components/LoadingSpinner';

const statusConfig: Record<string, { icon: React.ReactNode; color: string }> = {
  pending: { icon: <Clock size={16} />, color: 'text-yellow-400 bg-yellow-400/10' },
  shipped: { icon: <Truck size={16} />, color: 'text-blue-400 bg-blue-400/10' },
  delivered: { icon: <CheckCircle size={16} />, color: 'text-green-400 bg-green-400/10' },
  cancelled: { icon: <XCircle size={16} />, color: 'text-red-400 bg-red-400/10' },
};

export default function Orders() {
  const { lang, user } = useApp();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = user ? `?user_id=${user.id}` : '?all=true';
    fetch(`/api/orders${params}`)
      .then(r => r.json())
      .then(data => setOrders(Array.isArray(data) ? data : []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [user]);

  if (loading) return <div className="min-h-screen bg-slate-900 pt-24"><LoadingSpinner /></div>;

  return (
    <div className="min-h-screen bg-slate-900 pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-8">{t('orders.title', lang)}</h1>
        {orders.length === 0 ? (
          <div className="text-center py-20">
            <Package size={64} className="mx-auto text-gray-600 mb-4" />
            <p className="text-gray-400 text-lg">{t('orders.empty', lang)}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order, i) => {
              const items = typeof order.items === 'string' ? JSON.parse(order.items) : order.items;
              const sc = statusConfig[order.status] || statusConfig.pending;
              return (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50"
                >
                  <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                    <div>
                      <span className="text-gray-400 text-sm">#{order.id}</span>
                      <h3 className="text-white font-semibold">{order.customer_name}</h3>
                    </div>
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${sc.color}`}>
                      {sc.icon} {t(`orders.${order.status}`, lang)}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {(items || []).slice(0, 4).map((item: any, j: number) => (
                      <img key={j} src={item.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" />
                    ))}
                    {(items || []).length > 4 && <span className="w-12 h-12 rounded-lg bg-slate-700 flex items-center justify-center text-gray-400 text-xs">+{items.length - 4}</span>}
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">{new Date(order.created_at).toLocaleDateString(lang === 'ar' ? 'ar-MA' : 'en-US')}</span>
                    <span className="text-amber-400 font-bold">{order.total} {t('currency', lang)}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
