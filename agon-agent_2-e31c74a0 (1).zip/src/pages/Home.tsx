import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Smartphone, Wind, Package, ArrowRight, ArrowLeft, Truck, Shield, CreditCard } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import ProductCard from '../components/ProductCard';
import LoadingSpinner from '../components/LoadingSpinner';

const categoryIcons: Record<string, React.ReactNode> = {
  clothing: <ShoppingBag size={28} />,
  electronics: <Smartphone size={28} />,
  perfumes: <Wind size={28} />,
  general: <Package size={28} />,
};

export default function Home() {
  const { lang } = useApp();
  const [featured, setFeatured] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  useEffect(() => {
    fetch('/api/products?featured=true')
      .then(r => r.json())
      .then(data => { setFeatured(Array.isArray(data) ? data : []); })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const categories = ['clothing', 'electronics', 'perfumes', 'general'];

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/hero-bg.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-900/80 via-slate-900/70 to-slate-900" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-black text-white mb-6 leading-tight">
              {t('hero.title', lang)}
            </h1>
            <p className="text-lg sm:text-xl text-gray-300 mb-10 max-w-2xl mx-auto leading-relaxed">
              {t('hero.subtitle', lang)}
            </p>
            <Link
              to="/products"
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-900 font-bold text-lg rounded-2xl hover:from-amber-400 hover:to-amber-500 transition-all shadow-lg shadow-amber-500/25 active:scale-95"
            >
              {t('hero.cta', lang)}
              <Arrow size={20} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: <Truck size={24} />, title: lang === 'ar' ? 'توصيل سريع' : 'Fast Delivery', desc: lang === 'ar' ? 'توصيل لجميع المدن خلال 24-48 ساعة' : 'Delivery to all cities in 24-48 hours' },
              { icon: <Shield size={24} />, title: lang === 'ar' ? 'ضمان الجودة' : 'Quality Guarantee', desc: lang === 'ar' ? 'منتجات أصلية 100% مع ضمان الاسترجاع' : '100% authentic products with return guarantee' },
              { icon: <CreditCard size={24} />, title: lang === 'ar' ? 'دفع آمن' : 'Secure Payment', desc: lang === 'ar' ? 'وسائل دفع متعددة وآمنة' : 'Multiple secure payment methods' },
            ].map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.15 }}
                className="flex items-start gap-4 p-6 rounded-2xl bg-slate-800/50 border border-slate-700/50">
                <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400">{f.icon}</div>
                <div>
                  <h3 className="text-white font-semibold mb-1">{f.title}</h3>
                  <p className="text-gray-400 text-sm">{f.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white text-center mb-12">{t('categories.title', lang)}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories.map((cat, i) => (
              <motion.div key={cat} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.1 }}>
                <Link
                  to={`/products?category=${cat}`}
                  className="flex flex-col items-center gap-3 p-8 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-800/50 border border-slate-700/50 hover:border-amber-500/40 hover:shadow-lg hover:shadow-amber-500/5 transition-all group"
                >
                  <div className="p-4 rounded-2xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20 transition-colors">
                    {categoryIcons[cat]}
                  </div>
                  <span className="text-white font-medium text-sm">{t(`categories.${cat}`, lang)}</span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="py-20 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-white">{t('featured.title', lang)}</h2>
            <Link to="/products" className="text-amber-400 hover:text-amber-300 font-medium text-sm flex items-center gap-1">
              {lang === 'ar' ? 'عرض الكل' : 'View All'} <Arrow size={16} />
            </Link>
          </div>
          {loading ? <LoadingSpinner /> : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {featured.slice(0, 8).map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
