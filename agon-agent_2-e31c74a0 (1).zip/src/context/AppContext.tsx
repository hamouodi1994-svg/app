import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { Lang } from '../lib/i18n';
import supabase from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

interface AppContextType {
  lang: Lang;
  setLang: (l: Lang) => void;
  user: User | null;
  setUser: (u: User | null) => void;
  loading: boolean;
}

const AppContext = createContext<AppContextType>({
  lang: 'ar', setLang: () => {}, user: null, setUser: () => {}, loading: true
});

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('lang') as Lang) || 'ar');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    localStorage.setItem('lang', lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  return (
    <AppContext.Provider value={{ lang, setLang, user, setUser, loading }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
