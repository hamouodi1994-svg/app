import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Menu, X, Globe, LogOut, Shield } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import { useCart } from '../lib/cartStore';
import supabase from '../lib/supabase';

export default function Navbar() {
  const { lang, setLang, user } = useApp();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-900/95 backdrop-blur-md border-b border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
              <span className="text-slate-900 font-bold text-lg">س</span>
            </div>
            <span className="text-xl font-bold text-white hidden sm:block">{t('app.name', lang)}</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link to="/" className="text-gray-300 hover:text-amber-400 transition-colors text-sm font-medium">{t('nav.home', lang)}</Link>
            <Link to="/products" className="text-gray-300 hover:text-amber-400 transition-colors text-sm font-medium">{t('nav.products', lang)}</Link>
            {user && <Link to="/orders" className="text-gray-300 hover:text-amber-400 transition-colors text-sm font-medium">{t('nav.orders', lang)}</Link>}
            <Link to="/admin-login" className="flex items-center gap-1.5 text-gray-300 hover:text-amber-400 transition-colors text-sm font-medium">
              <Shield size={14} />
              {t('nav.admin', lang)}
            </Link>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="p-2 rounded-lg text-gray-400 hover:text-amber-400 hover:bg-slate-800 transition-all" title="Switch language">
              <Globe size={18} />
            </button>
            <Link to="/cart" className="relative p-2 rounded-lg text-gray-400 hover:text-amber-400 hover:bg-slate-800 transition-all">
              <ShoppingCart size={18} />
              {count > 0 && <span className="absolute -top-1 -right-1 bg-amber-500 text-slate-900 text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">{count}</span>}
            </Link>
            {user ? (
              <button onClick={handleLogout} className="p-2 rounded-lg text-gray-400 hover:text-red-400 hover:bg-slate-800 transition-all" title={t('nav.logout', lang)}>
                <LogOut size={18} />
              </button>
            ) : (
              <Link to="/login" className="px-4 py-2 rounded-lg bg-amber-500 text-slate-900 font-semibold text-sm hover:bg-amber-400 transition-colors">
                {t('nav.login', lang)}
              </Link>
            )}
            <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-lg text-gray-400 hover:text-white">
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {open && (
        <div className="md:hidden bg-slate-900 border-t border-slate-800 px-4 py-4 space-y-3">
          <Link to="/" onClick={() => setOpen(false)} className="block text-gray-300 hover:text-amber-400 py-2">{t('nav.home', lang)}</Link>
          <Link to="/products" onClick={() => setOpen(false)} className="block text-gray-300 hover:text-amber-400 py-2">{t('nav.products', lang)}</Link>
          {user && <Link to="/orders" onClick={() => setOpen(false)} className="block text-gray-300 hover:text-amber-400 py-2">{t('nav.orders', lang)}</Link>}
          <Link to="/admin-login" onClick={() => setOpen(false)} className="flex items-center gap-1.5 text-gray-300 hover:text-amber-400 py-2">
            <Shield size={14} />
            {t('nav.admin', lang)}
          </Link>
        </div>
      )}
    </nav>
  );
}
