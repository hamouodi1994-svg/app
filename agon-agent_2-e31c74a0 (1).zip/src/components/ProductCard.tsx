import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import { useCart } from '../lib/cartStore';

interface Product {
  id: number;
  name_ar: string;
  name_en: string;
  description_ar: string;
  description_en: string;
  price: number;
  category: string;
  image_url: string;
  stock: number;
  featured: boolean;
  rating?: number;
}

export default function ProductCard({ product }: { product: Product }) {
  const { lang } = useApp();
  const { addItem } = useCart();
  const name = lang === 'ar' ? product.name_ar : product.name_en;
  const categoryLabel = t(`categories.${product.category}`, lang);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      id: product.id,
      name_ar: product.name_ar,
      name_en: product.name_en,
      price: product.price,
      image_url: product.image_url,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="group"
    >
      <Link to={`/product/${product.id}`} className="block">
        <div className="bg-slate-800/50 rounded-2xl overflow-hidden border border-slate-700/50 hover:border-amber-500/40 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/10">
          <div className="relative aspect-square overflow-hidden">
            <img
              src={product.image_url}
              alt={name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
            <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-medium bg-amber-500/90 text-slate-900">
              {categoryLabel}
            </span>
            {product.featured && (
              <span className="absolute top-3 right-3 px-2 py-1 rounded-full text-xs font-medium bg-rose-500 text-white flex items-center gap-1">
                <Star size={10} fill="currentColor" /> {lang === 'ar' ? 'مميز' : 'Featured'}
              </span>
            )}
          </div>
          <div className="p-4">
            <h3 className="text-white font-semibold text-sm mb-2 line-clamp-1">{name}</h3>
            <div className="flex items-center justify-between">
              <span className="text-amber-400 font-bold text-lg">{product.price} <span className="text-xs text-gray-400">{t('currency', lang)}</span></span>
              <button
                onClick={handleAdd}
                className="p-2.5 rounded-xl bg-amber-500 text-slate-900 hover:bg-amber-400 transition-colors active:scale-95"
              >
                <ShoppingCart size={16} />
              </button>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
