
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';

export default function LoadingSpinner() {
  const { lang } = useApp();
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="w-12 h-12 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      <p className="mt-4 text-gray-400 text-sm">{t('loading', lang)}</p>
    </div>
  );
}
