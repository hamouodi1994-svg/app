
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';

export default function Footer() {
  const { lang } = useApp();
  return (
    <footer className="bg-slate-900 border-t border-slate-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
                <span className="text-slate-900 font-bold text-lg">س</span>
              </div>
              <span className="text-xl font-bold text-white">{t('app.name', lang)}</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              {lang === 'ar' ? 'متجرك الإلكتروني المفضل لأفضل المنتجات بأسعار تنافسية.' : 'Your favorite online store for the best products at competitive prices.'}
            </p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">{lang === 'ar' ? 'روابط سريعة' : 'Quick Links'}</h3>
            <div className="space-y-2">
              <a href="/products" className="block text-gray-400 hover:text-amber-400 text-sm transition-colors">{t('nav.products', lang)}</a>
              <a href="/cart" className="block text-gray-400 hover:text-amber-400 text-sm transition-colors">{t('nav.cart', lang)}</a>
              <a href="#" className="block text-gray-400 hover:text-amber-400 text-sm transition-colors">{t('footer.about', lang)}</a>
              <a href="#" className="block text-gray-400 hover:text-amber-400 text-sm transition-colors">{t('footer.contact', lang)}</a>
            </div>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">{t('footer.contact', lang)}</h3>
            <div className="space-y-2 text-gray-400 text-sm">
              <p>contact@souq-elegance.com</p>
              <p>+212 600 000 000</p>
              <p>{lang === 'ar' ? 'الدار البيضاء، المغرب' : 'Casablanca, Morocco'}</p>
            </div>
          </div>
        </div>
        <div className="border-t border-slate-800 mt-8 pt-6 text-center text-gray-500 text-sm">
          © 2025 {t('app.name', lang)} — {t('footer.rights', lang)}
        </div>
      </div>
    </footer>
  );
}
